Diogo Ferreira Neves, 202006343
Fábio Almeida Teixeira, 202006345
João de Oliveira Gigante Pinheiro, 202008133
Mafalda Bastos da Costa, 202006417